﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogisticsDA_Lib.Models
{
    public class Maintenance
    {
        public int ScheduleId { get; set; }
        public int EquipmentId { set; get; }
        public string Description { get; set; }
        public DateTime ScheduledDate { get; set; }
        public string CompletionStatus { get; set; }

        public override string ToString()
        {
            return String.Format($"{ScheduleId,10}{EquipmentId,10}{Description,40}{ScheduledDate,20}{CompletionStatus,20}");
        }
    }
}
