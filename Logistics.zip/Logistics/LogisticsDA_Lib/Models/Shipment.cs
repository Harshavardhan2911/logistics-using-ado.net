﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogisticsDA_Lib.Models
{
    public class Shipment
    {
        public int ShipmentId { get; set; }

        public int ItemId { get; set; }

        public string Origin { get; set; }

        public string Destination { get; set; }

        public string Status { get; set; }

        public DateTime ExpectedDelivery { get; set; }



        public override string ToString()

        {

            return string.Format($"{ShipmentId,12}{ItemId,12}{Origin,20}{Destination,30}{Status,20}{ExpectedDelivery,40}");

        }





    }
}
