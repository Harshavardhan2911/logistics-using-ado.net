﻿using LogisticsDA_Lib.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogisticsDA_Lib.Repositories
{
    public class SpaceRepository:ISpRepository<Space>
    {
         SqlConnection con;

        public SpaceRepository()
        {
            con = new SqlConnection(ConnectionString);
            con.Open();
        }

        public String ConnectionString
        {
            get
            {
                return "Data Source=LTIN463808\\SQLEXPRESS;Initial Catalog=logistics;Integrated Security=True";
            }
        }
        public bool AllocateSpace(Space entity)
        {
            bool b = false;
            try
            {

                SqlCommand cmd = new SqlCommand("INSERT INTO SPACE VALUES(@p1,@p2,@p3,@p4)", con);

                cmd.Parameters.AddWithValue("@p1", entity.TotalCapacity);
                cmd.Parameters.AddWithValue("@p2", entity.UsedCapacity);
                cmd.Parameters.AddWithValue("@p3", entity.AvailableCapacity);
                cmd.Parameters.AddWithValue("@p4", entity.Zone);
                int rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                {
                    b = true;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Insert Operation Failed -" + ex.Message);
                b = false;
            }
            return b;
        }

        public bool FreeSpace(Space entity)
        {
            bool b = false;
            try
            {

                SqlCommand cmd = new SqlCommand("DELETE FROM SPACE WHERE spaceId=@p1", con);

                cmd.Parameters.AddWithValue("@p1", entity.SpaceId);
                int rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                {
                    b = true;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Delete Operation Failed -" + ex.Message);
                b = false;
            }
            return b;
        }


        public Space Get(object id)
        {
            string zone = (string)id;
            List<Space> spaces = ViewAllSpace();
            Space space = spaces.Where(s => Convert.ToString(s.SpaceId) == zone).FirstOrDefault();
            return space;
        }
        public List<Space> ViewAllSpace()
        {
            List<Space> spaces = new List<Space>();
            SqlCommand cmd = new SqlCommand("Select * from Space", con);
            SqlDataReader sqldr = cmd.ExecuteReader();
            while (sqldr.Read())
            {
                Space s = new Space()
                {
                    SpaceId= Convert.ToInt32(sqldr[0].ToString()),
                    TotalCapacity = Convert.ToInt32(sqldr[1].ToString()),
                    UsedCapacity = Convert.ToInt32(sqldr[2].ToString()),
                    AvailableCapacity = Convert.ToInt32(sqldr[3].ToString()),
                    Zone = sqldr[4].ToString()
                };
                spaces.Add(s);
            }
            sqldr.Close();
            return spaces;
        }
    }
}
