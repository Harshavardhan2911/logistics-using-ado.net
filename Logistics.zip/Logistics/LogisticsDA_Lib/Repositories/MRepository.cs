﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogisticsDA_Lib.Repositories
{
    public interface IMRepository<T> where T:class
    {
        bool ScheduleMaintenance(T entity);
        bool UpdateSchedule(T entity);
        // bool Delete(T entity);
        List<T> ViewSchedule();
        T Get(object obj);

    }
}
