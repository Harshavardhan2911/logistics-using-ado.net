﻿using LogisticsDA_Lib.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogisticsDA_Lib.Repositories
{
    public class InventoryRepository : IIRepository<Inventory>
    {
        SqlConnection con;
        public InventoryRepository()
        {
            con = new SqlConnection(ConnectionString);
            con.Open();
        }
        public string ConnectionString
        {
            get
            {
                return "Data Source=LTIN463808\\SQLEXPRESS;Initial Catalog=logistics;Integrated Security=True";
            }
        }
        public bool AddItem(Inventory entity)
        {
            bool b = false;
            try
            {
                SqlCommand cmd = new SqlCommand("INSERT INTO INVENTORY (ItemName, Category, Quantity, Location, LastUpdated) VALUES(@p1,@p2,@p3,@p4,@p5)", con);
                cmd.Parameters.AddWithValue("@p1", entity.ItemName);
                cmd.Parameters.AddWithValue("@p2", entity.Category);
                cmd.Parameters.AddWithValue("@p3", entity.Quantity);
                cmd.Parameters.AddWithValue("@p4", entity.Location);
                cmd.Parameters.AddWithValue("@p5", entity.LastUpdated);
                int rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                {
                    b = true;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Insert Operation Failed -" + ex.Message);
                b = false;
            }
            return b;
        }



        public bool RemoveItem(Inventory entity)
        {
            bool b = false;
            try
            {
                SqlCommand cmd = new SqlCommand("DELETE FROM INVENTORY where itemId=@p1", con);

                cmd.Parameters.AddWithValue("@p1", entity.ItemId);
                int rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                {
                    b = true;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Delete Operation Failed -" + ex.Message);
                b = false;
            }
            return b;
        }

        public Inventory Get(object id)
        {
            string itemId = (string)id;
            List<Inventory> list = ViewItem();
            Inventory inventory = list.Where(i => Convert.ToString(i.ItemId) == itemId).FirstOrDefault();
            return inventory;
        }

        public List<Inventory> ViewItem()
        {
            List<Inventory> list = new List<Inventory>();
            SqlCommand cmd = new SqlCommand("Select * from Inventory", con);
            SqlDataReader sqldr = cmd.ExecuteReader();
            while (sqldr.Read())
            {
                Inventory i = new Inventory()
                {
                    ItemId = Convert.ToInt32(sqldr[0]),
                    ItemName = sqldr[1].ToString(),
                    Category = sqldr[2].ToString(),
                    Quantity = Convert.ToInt32(sqldr[3]),
                    Location = sqldr[4].ToString(),
                    LastUpdated = Convert.ToDateTime(sqldr[5])

                };
                list.Add(i);
            }
            sqldr.Close();
            return list;

        }

        public bool UpdateItem(Inventory entity)
        {
            bool b = false;
            try
            {
                SqlCommand cmd = new SqlCommand("Update INVENTORY Set ItemName=@p2,category=@p3, quantity=@p4, location=@p5, lastUpdated=@p6 where itemId=@p1", con);

                cmd.Parameters.AddWithValue("@p2", entity.ItemName);
                cmd.Parameters.AddWithValue("@p3", entity.Category);
                cmd.Parameters.AddWithValue("@p4", entity.Quantity);
                cmd.Parameters.AddWithValue("@p5", entity.Location);
                cmd.Parameters.AddWithValue("@p6", entity.LastUpdated);
                cmd.Parameters.AddWithValue("@p1", entity.ItemId);
                int rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                {
                    b = true;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Update Operation Failed -" + ex.Message);
                b = false;
            }
            return b;
        }
        

    }
}
