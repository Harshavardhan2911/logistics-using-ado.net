﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogisticsDA_Lib.Repositories
{
    public interface ISpRepository<T> where T:class
    {
        bool AllocateSpace(T entity);
        bool FreeSpace(T entity);
        // bool Update(T entity);
        List<T> ViewAllSpace();

        // T Get(object id);

    }
}
