﻿using LogisticsDA_Lib.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogisticsDA_Lib.Repositories
{
    public class ReportRepository:IRRepository<Report>
    {
         SqlConnection con;

        public ReportRepository()
        {
            try
            {
                con = new SqlConnection(ConnectionString);
                con.Open();
            }
            catch (SqlException ex)
            {
                Console.WriteLine($"Error opening database connection: {ex.Message}");
                throw;
            }
        }

        public string ConnectionString
        {
            get
            {
                return "Data Source=LTIN463808\\SQLEXPRESS;Initial Catalog=logistics;Integrated Security=True";
            }
        }

        public bool GenerateReport(Report entity)
        {
            bool b = false;
            try
            {

                SqlCommand cmd = new SqlCommand("INSERT INTO Report VALUES (@reportType, @generatedOn, @details)", con);

                cmd.Parameters.AddWithValue("@reportType", entity.ReportType);
                cmd.Parameters.AddWithValue("@generatedOn", entity.GeneratedOn);
                cmd.Parameters.AddWithValue("@details", entity.Details);
                int rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                { 
                b = true;
            }
                }
            
            catch (SqlException ex)
            {
                Console.WriteLine($"Error adding report: {ex.Message}");
                b=false;
            }
            return b;
        }

        public List<Report> DownloadReport()
        {
            List<Report> m = new List<Report>();
            SqlCommand cmd = new SqlCommand("Select * from Report", con);
            SqlDataReader sqldr = cmd.ExecuteReader();
            while (sqldr.Read())
            {
                Report a = new Report()
                {
                    ReportId = Convert.ToInt32(sqldr[0].ToString()),
                    ReportType = sqldr[1].ToString(),
                    
                    GeneratedOn = Convert.ToDateTime(sqldr[2].ToString()),
                    Details = sqldr[3].ToString()


                };
                m.Add(a);

            }
            sqldr.Close();
            return m;
        }
      public Report Get(object obj)
        {
            string reportId = (string)obj;
            List<Report> m = DownloadReport();
            Report schedule = m.Where(d => Convert.ToString(d.ReportId) == reportId).FirstOrDefault();
            return schedule;

        }

        
    }
}
