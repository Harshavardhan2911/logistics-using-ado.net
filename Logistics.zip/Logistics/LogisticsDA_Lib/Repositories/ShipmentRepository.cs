﻿using LogisticsDA_Lib.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogisticsDA_Lib.Repositories
{
    public class ShipmentRepository :IShRepository<Shipment>
    {
         SqlConnection con;

        public ShipmentRepository()

        {

            con = new SqlConnection(ConnectionString);

            con.Open();

        }

        public string ConnectionString

        {

            get

            {

                return "Data Source=LTIN463808\\SQLEXPRESS;Initial Catalog=logistics;Integrated Security=True";

            }

        }

        public bool ReceiveShipment(Shipment entity)

        {

            bool b = false;

            try

            {

                SqlCommand cmd = new SqlCommand("INSERT INTO SHIPMENT VALUES(@p1,@p2,@p3,@p4,@p5)", con);

                cmd.Parameters.AddWithValue("@p1", entity.ItemId);

                cmd.Parameters.AddWithValue("@p2", entity.Origin);

                cmd.Parameters.AddWithValue("@p3", entity.Destination);

                cmd.Parameters.AddWithValue("@p4", entity.Status);

                cmd.Parameters.AddWithValue("@p5", entity.ExpectedDelivery);

                int rows = cmd.ExecuteNonQuery();

                if (rows > 0)

                {

                    b = true;

                }

            }

            catch (Exception ex)

            {

                Console.WriteLine("Insert Operation Failed-" + ex.Message);

                b = false;

            }

            return b;



        }



       public Shipment Get(object id)

        {

            int shipmentId = (int)id;

            List<Shipment> shipments = GetAll();

            Shipment shipment = shipments.Where(s =>Convert.ToInt32( s.ShipmentId) == shipmentId).FirstOrDefault();// LINQ syntax 

            return shipment;



        }



        public List<Shipment> GetAll()

        {

            List<Shipment> shipments = new List<Shipment>();

            SqlCommand cmd = new SqlCommand("Select * from Shipment", con);

            SqlDataReader sqldr = cmd.ExecuteReader();

            while (sqldr.Read())

            {

                Shipment s = new Shipment()

                {

                    ShipmentId =Convert.ToInt32( sqldr[0]),

                    ItemId = Convert.ToInt32(sqldr[1]),

                    Origin = sqldr[2].ToString(),

                    Destination = sqldr[3].ToString(),

                    Status = sqldr[4].ToString(),

                    ExpectedDelivery = Convert.ToDateTime(sqldr[5].ToString()),

                };

                shipments.Add(s);

            }

            sqldr.Close();

            return shipments;



        }



        public bool DispatchShipment(Shipment entity)

        {
            bool b = false;

            try

            {

                SqlCommand cmd = new SqlCommand("UPDATE  SHIPMENT SET ItemId=@p2,Origin=@p3,Destination=@p4,Status=@p5 ,ExpectedDelivery=@p6 where ShipmentId=@p1", con);

                cmd.Parameters.AddWithValue("@p2", entity.ItemId);

                cmd.Parameters.AddWithValue("@p3", entity.Origin);

                cmd.Parameters.AddWithValue("@p4", entity.Destination);

                cmd.Parameters.AddWithValue("@p5", entity.Status);

                cmd.Parameters.AddWithValue("@p6", entity.ExpectedDelivery);
                cmd.Parameters.AddWithValue("@p1", entity.ShipmentId);

                int rows = cmd.ExecuteNonQuery();

                if (rows > 0)

                {

                    b = true;

                }

            }

            catch (Exception ex)

            {

                Console.WriteLine("Insert Operation Failed-" + ex.Message);

                b = false;

            }

            return b;



        }



        public bool TrackShipment(Shipment entity)

        {

            throw new NotImplementedException();

        }

    }

} 

 

    