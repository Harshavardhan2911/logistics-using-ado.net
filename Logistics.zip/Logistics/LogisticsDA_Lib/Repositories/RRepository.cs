﻿using LogisticsDA_Lib.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogisticsDA_Lib.Repositories
{
    public interface IRRepository<T> where T:class
    {
        bool GenerateReport(T entity);
        List<T> DownloadReport( );
        T Get(object obj);





    }
}
