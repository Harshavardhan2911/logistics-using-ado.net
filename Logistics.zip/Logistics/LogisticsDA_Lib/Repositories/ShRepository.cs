﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogisticsDA_Lib.Repositories
{
    public interface IShRepository<T> where T:class
    {
        bool ReceiveShipment(T entity);

        bool DispatchShipment(T entity);

        bool TrackShipment(T entity);

        List<T> GetAll();



        T Get(object id);
    }
}
