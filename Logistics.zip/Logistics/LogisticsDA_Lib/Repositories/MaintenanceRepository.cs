﻿using LogisticsDA_Lib.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogisticsDA_Lib.Repositories
{
   public class MaintenanceRepository:IMRepository<Maintenance>
    {
         SqlConnection con;
        public MaintenanceRepository()
        {
            con = new SqlConnection(ConnectionString);
            con.Open();
        }
        public string ConnectionString
        {
            get
            {
                return "Data Source=LTIN463808\\SQLEXPRESS;Initial Catalog=logistics;Integrated Security=True";
            }
        }
        public bool ScheduleMaintenance(Maintenance entity)
        {
            bool b = false;
            try
            {
                SqlCommand cmd = new SqlCommand("INSERT INTO MAINTENANCE VALUES(@p1,@p2,@p3,@p4)", con);
                //  cmd.Parameters.AddWithValue("@p1", entity.ScheduleId);
                cmd.Parameters.AddWithValue("@p1", entity.EquipmentId);
                cmd.Parameters.AddWithValue("@p2", entity.Description);
                cmd.Parameters.AddWithValue("@p3", entity.ScheduledDate);
                cmd.Parameters.AddWithValue("@p4", entity.CompletionStatus);
                int rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                {
                    b = true;
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine("Insert Operation Failed-" + ex.Message);
                b = false;

            }
            return b;
        }

        public bool Delete(Maintenance entity)
        {
            throw new NotImplementedException();
        }

        public List<Maintenance> ViewSchedule()
        {
            List<Maintenance> m = new List<Maintenance>();
            SqlCommand cmd = new SqlCommand("Select * from Maintenance", con);
            SqlDataReader sqldr = cmd.ExecuteReader();
            while (sqldr.Read())
            {
                Maintenance a = new Maintenance()
                {
                    ScheduleId = Convert.ToInt32(sqldr[0].ToString()),
                    EquipmentId = Convert.ToInt32(sqldr[1].ToString()),
                    Description = sqldr[2].ToString(),
                    ScheduledDate = Convert.ToDateTime(sqldr[3].ToString()),
                    CompletionStatus = sqldr[4].ToString()


                };
                m.Add(a);

            }
            sqldr.Close();
            return m;
        }

        public Maintenance Get(object obj)
        {
            string scheduleId = (string)obj;
            List<Maintenance> m = ViewSchedule();
            Maintenance schedule = m.Where(d => Convert.ToString(d.ScheduleId) == scheduleId).FirstOrDefault();
            return schedule;

        }

        public bool UpdateSchedule(Maintenance entity)
        {

            bool b = false;
            try
            {
                SqlCommand cmd = new SqlCommand("UPDATE Maintenance Set EquipmentId=@p2,Description=@p3,ScheduledDate=@p4,CompletionStatus=@p5 where ScheduleId=@p1 ", con);

                cmd.Parameters.AddWithValue("@p2", entity.EquipmentId);
                cmd.Parameters.AddWithValue("@p3", entity.Description);
                cmd.Parameters.AddWithValue("@p4", entity.ScheduledDate);
                cmd.Parameters.AddWithValue("@p5", entity.CompletionStatus);
                cmd.Parameters.AddWithValue("@p1", entity.ScheduleId);
                int rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                {
                    b = true;
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine("Insert Operation Failed-" + ex.Message);
                b = false;

            }
            return b;

        }
    }
}
