﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogisticsDA_Lib.Repositories
{
    public interface IIRepository<T> where T:class
    {
        bool AddItem(T entity);
        bool UpdateItem(T entity);
        bool RemoveItem(T entity);
        List<T> ViewItem();
        T Get(object id);
    }
}
