﻿using Logistics.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logistics.Repositories
{
    public class InventoryRepository:IRepository<Inventory>
    {
        SqlConnection con;
        public InventoryRepository()
        {
            con = new SqlConnection(ConnectionString);
            con.Open();
        }
        public string ConnectionString
        {
            get
            {
                return "Data Source=LTIN463808\\SQLEXPRESS;Initial Catalog=logistics;Integrated Security=True";
            }
        }
        public bool addItem(Inventory entity)
        {
            bool b = false;
            try
            {
                SqlCommand cmd = new SqlCommand("INSERT INTO INVENTORY (ItemName, Category, Quantity, Location, LastUpdated) VALUES(@p1,@p2,@p3,@p4,@p5)", con);
                cmd.Parameters.AddWithValue("@p1", entity.itemName);
                cmd.Parameters.AddWithValue("@p2", entity.category);
                cmd.Parameters.AddWithValue("@p3", entity.quantity);
                cmd.Parameters.AddWithValue("@p4", entity.location);
                cmd.Parameters.AddWithValue("@p5", entity.lastUpdated);
                int rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                {
                    b = true;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Insert Operation Failed -" + ex.Message);
                b = false;
            }
            return b;
        }



        public bool removeItem(Inventory entity)
        {
            bool b = false;
            try
            {
                SqlCommand cmd = new SqlCommand("DELETE FROM INVENTORY where itemName=@p1", con);

                cmd.Parameters.AddWithValue("@p1", entity.itemName);
                int rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                {
                    b = true;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Delete Operation Failed -" + ex.Message);
                b = false;
            }
            return b;
        }

        public Inventory Get(object id)
        {
            string itemName = (string)id;
            List<Inventory> list = viewItem();
            Inventory inventory = list.Where(i => i.itemName == itemName).FirstOrDefault();
            return inventory;
        }

        public List<Inventory> viewItem()
        {
            List<Inventory> list = new List<Inventory>();
            SqlCommand cmd = new SqlCommand("Select * from Inventory", con);
            SqlDataReader sqldr = cmd.ExecuteReader();
            while (sqldr.Read())
            {
                Inventory i = new Inventory()
                {
                    itemName = sqldr[1].ToString(),
                    category = sqldr[2].ToString(),
                    quantity = Convert.ToInt32(sqldr[3]),
                    location = sqldr[4].ToString(),
                    lastUpdated = Convert.ToDateTime(sqldr[5])

                };
                list.Add(i);
            }
            sqldr.Close();
            return list;

        }

        public bool updateItem(Inventory entity)
        {
            bool b = false;
            try
            {
                SqlCommand cmd = new SqlCommand("Update INVENTORY Set category=@p2, quantity=@p3, location=@p4, lastUpdated=@p5 where itemName=@p1", con);


                cmd.Parameters.AddWithValue("@p2", entity.category);
                cmd.Parameters.AddWithValue("@p3", entity.quantity);
                cmd.Parameters.AddWithValue("@p4", entity.location);
                cmd.Parameters.AddWithValue("@p5", entity.lastUpdated);
                cmd.Parameters.AddWithValue("@p1", entity.itemName);
                int rows = cmd.ExecuteNonQuery();
                if (rows > 0)
                {
                    b = true;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Update Operation Failed -" + ex.Message);
                b = false;
            }
            return b;
        }
    }
}
    

