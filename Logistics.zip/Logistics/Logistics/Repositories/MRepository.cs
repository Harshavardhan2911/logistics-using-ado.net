﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logistics.Repositories
{
    interface MRepository<T> where T:class
    {
    }
}
