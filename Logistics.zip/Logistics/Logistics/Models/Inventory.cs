﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Logistics.Models
{
    public class Inventory
    {
        public int itemId { get; set; }
        public string itemName { get; set; }
        public string category { get; set; }
        public int quantity { get; set; }
        public string location { get; set; }
        public DateTime lastUpdated { get; set; }

        public override string ToString()
        {
            return String.Format($"{itemName,20}{category,20}{quantity,10}{location,20}   {lastUpdated:yyyy-MM-dd HH:mm:ss}");
        }
    }
}
