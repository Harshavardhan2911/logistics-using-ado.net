﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogisticsBO_Lib.Models
{
   public class Space
    {
        public int SpaceId { get; set; }
        public int TotalCapacity { get; set; }
        public int UsedCapacity { get; set; }
        public int AvailableCapacity { get; set; }
        public string Zone { get; set; }

        public override string ToString()
        {
            return String.Format($"{SpaceId,20}{TotalCapacity,20}{UsedCapacity,20}{AvailableCapacity,20}{Zone,30}");

        }
    }
}
