﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LogisticsDA_Lib.Models;
using LogisticsDA_Lib.Repositories;

namespace LogisticsBO_Lib.Models
{
   public class SpaceBO
    {
       public static SpaceRepository spRep = new SpaceRepository();

        public static void SearchSpace(string id)
        {
            var space = spRep.Get(id);
            if (space == null)
            {
                Console.WriteLine($"{id} is invalid");
            }
            else
            {
                Console.WriteLine($"{space}");
            }
        }

        public static void RemoveSpace(string id)
        {
            var space = spRep.Get(id);
            if (space == null)
            {
                Console.WriteLine($"{id} is .invalid");
            }
            else
            {
                if (spRep.FreeSpace(space))
                {
                    Console.WriteLine($" Space having {id} is deleted.");

                }

                else
                {
                    Console.WriteLine("Deletion Failed");

                }
            }
        }



        public static void Viewspaces()
        {
            var spaces = spRep.ViewAllSpace();
            Console.WriteLine("{0,20}{1, 20}{2, 20}{3, 20}{4, 30}", "spaceId","totalCapacity", "usedCapacity", "availableCapacity", "zone");
            foreach (var space in spaces)
            {
                Console.WriteLine($"{space}");
            }


        }

        public static void Allocate(Models.Space s)
        {
            LogisticsDA_Lib.Models.Space sp = new LogisticsDA_Lib.Models.Space()
            {
                SpaceId = s.SpaceId,
                TotalCapacity = s.TotalCapacity,
                UsedCapacity = s.UsedCapacity,
                AvailableCapacity = s.AvailableCapacity,
                Zone = s.Zone
            };

            if (spRep.AllocateSpace(sp))
            {
                Console.WriteLine("Space Detailes Added ! ");
            }
            else
            {
                Console.WriteLine("Space Detailes Could not be Added ! ");
            }
        }
    }
}
