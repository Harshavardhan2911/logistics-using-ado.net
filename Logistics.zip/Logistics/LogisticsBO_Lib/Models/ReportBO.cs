﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LogisticsDA_Lib.Models;
using LogisticsDA_Lib.Repositories;


namespace LogisticsBO_Lib.Models
{
    public class ReportBO {

        public static ReportRepository mainRep = new ReportRepository();


        public static void GenerateReport(Report m)
        {
            LogisticsDA_Lib.Models.Report maint = new LogisticsDA_Lib.Models.Report()
            {
                ReportId = m.ReportId,
                ReportType = m.ReportType,
              
                GeneratedOn = m.GeneratedOn,
                Details = m.Details,

            };
            if (mainRep.GenerateReport(maint))
            {
                Console.WriteLine("GenerateReport Details added");
            }
            else
            {
                Console.WriteLine("GenerateReport Details not added");
            }
        }
        public static void DownloadReport()
        {
            var report = mainRep.DownloadReport();
            Console.WriteLine("{0,12}{1,20}{2,30}{3,40}", "ReportId", "ReportType",  "GeneratedOn", "Details");
            foreach (var maint in report)
            {
                Console.WriteLine($"{maint}");
            }
        }
    }
}
