﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogisticsBO_Lib.Models
{
    public class Report
    {
        public int ReportId { get; set; }
        public string ReportType { get; set; }
        public DateTime GeneratedOn { get; set; }
        public string Details { get; set; }
        public override string ToString()
        {
            return String.Format($"{ReportId,12}{ReportType,20}{GeneratedOn,30}{Details,40}");
        }
    }
}
