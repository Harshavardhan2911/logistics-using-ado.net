﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LogisticsDA_Lib.Models;
using LogisticsDA_Lib.Repositories;

namespace LogisticsBO_Lib.Models
{
    public class MaintenanceBO
    {
       public static MaintenanceRepository mainRep = new MaintenanceRepository();
        //private static object maintenance;

        //public static object maintenance;

        public static void UpdateSchedule(string scheduleId)
        {

            var schedule = mainRep.Get(scheduleId);
            if (schedule == null)
            {
                Console.WriteLine($"{scheduleId} is invalid");
            }
            else
            {
                Console.WriteLine("Re-enter EquipmentId,Description,ScheduledDate and CompletionStatus");
                LogisticsDA_Lib.Models.Maintenance maint = new LogisticsDA_Lib.Models.Maintenance()
                {

                    ScheduleId = schedule.ScheduleId,
                    EquipmentId = Convert.ToInt32(Console.ReadLine()),
                    Description = Console.ReadLine(),
                    ScheduledDate = Convert.ToDateTime(Console.ReadLine()),
                    CompletionStatus = Console.ReadLine()

                };
                if (mainRep.UpdateSchedule(maint))
                {
                    Console.WriteLine("Schedule Details modified");
                }
                else
                {
                    Console.WriteLine("Schedule Details not modified");
                }
            }



        }
        public static void SearchSchedule(string scheduleId)
        {
            var schedule = mainRep.Get(scheduleId);
            if (schedule == null)
            {
                Console.WriteLine($"{scheduleId} is invalid");
            }
            else
            {
                Console.WriteLine($"{schedule}");
            }
        }
        public static void ScheduleMaintenance(Maintenance maintenance)
        {
            LogisticsDA_Lib.Models.Maintenance maint = new LogisticsDA_Lib.Models.Maintenance()
            {
                ScheduleId = maintenance.ScheduleId,
                EquipmentId = maintenance.EquipmentId,
                Description = maintenance.Description,
                ScheduledDate = maintenance.ScheduledDate,
                CompletionStatus = maintenance.CompletionStatus,

            };
            if (mainRep.ScheduleMaintenance(maint))
            {
                Console.WriteLine("ScheduleMaintenance Details added");
            }
            else
            {
                Console.WriteLine("ScheduleMaintenance Details not added");
            }
        }
        public static void DisplaySchedule()
        {
            var maintenance = mainRep.ViewSchedule();
            Console.WriteLine("{0,10}{1,10}{2,40}{3,20}{4,20}", "ScheduleId", "EquipmentId", "Description", "ScheduledDate", "CompletionStatus");
            foreach (var maint in maintenance)
            {
                Console.WriteLine($"{maint}");
            }
        }
    }
}

   
