﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogisticsBO_Lib.Models
{
    public class Inventory
    {
        public int ItemId { get; set; }
        public string ItemName { get; set; }
        public string Category { get; set; }
        public int Quantity { get; set; }
        public string Location { get; set; }
        public DateTime LastUpdated { get; set; }

        public override string ToString()
        {
            return String.Format($"{ItemId,20}{ItemName,20}{Category,20}{Quantity,10}{Location,20}   {LastUpdated:yyyy-MM-dd HH:mm:ss}");
        }
    }
}
