﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LogisticsDA_Lib.Models;
using LogisticsDA_Lib.Repositories;


namespace LogisticsBO_Lib.Models
{
    public class InventoryBO
    {
        public static InventoryRepository invRep = new InventoryRepository();

        public static void UpdateInventory(string itemId)
        {
            var inventory = invRep.Get(itemId);
            if (inventory == null)
            {
                Console.WriteLine($"{itemId} is invalid");
            }
            else
            {
                Console.WriteLine("Re-enter Itemname;Category, Quantity, Location, LastUpdatedDateTime");
                LogisticsDA_Lib.Models.Inventory inv = new LogisticsDA_Lib.Models.Inventory()
                {
                    ItemId= inventory.ItemId,
                    ItemName = Console.ReadLine(),
                    Category = Console.ReadLine(),
                    Quantity = int.Parse(Console.ReadLine()),
                    Location = Console.ReadLine(),
                    LastUpdated = DateTime.Parse(Console.ReadLine())
                };

                if (invRep.UpdateItem(inv))
                {
                    Console.WriteLine("Inventory Details Updated !");
                }
                else
                {
                    Console.WriteLine("Inventory Details Could not be Updated !");
                }
            }
        }

        public static void SearchInventory(string itemId)
        {
            var inventory = invRep.Get(itemId);
            if (inventory == null)
            {
                Console.WriteLine($"{itemId} is invalid.");

            }
            else
            {
                Console.WriteLine($"{inventory}");

            }
        }

        public static void RemoveInventory(string itemId)
        {
            var inventory = invRep.Get(itemId);
            if (inventory == null)
            {
                Console.WriteLine($"{itemId} is invalid");
            }
            else
            {
                if (invRep.RemoveItem(inventory))
                {
                    Console.WriteLine($"Inventory having {itemId} is deleted.");
                }
                else
                {
                    Console.WriteLine("Deletion FAILED");
                }
            }
        }
        public static void AddInventory(Inventory inventory)
        {
            LogisticsDA_Lib.Models.Inventory inv = new LogisticsDA_Lib.Models.Inventory()
            {
                ItemName = inventory.ItemName,
                Category = inventory.Category,
                Quantity = inventory.Quantity,
                Location = inventory.Location,
                LastUpdated = inventory.LastUpdated,
            };

            if (invRep.AddItem(inv))
            {
                Console.WriteLine("Inventory Details Added !");
            }
            else
            {
                Console.WriteLine("Inventory Details Could not be Added !");
            }

        }

        public static void ViewInventory()
        {
            var list = invRep.ViewItem();
            Console.WriteLine("{0,20}{1,20}{2,10}{3,20}{4,20}{5,20}","ItemId", "itemName", "category", "quantity", "location", "lastUpdated");
            foreach (var item in list)
            {
                Console.WriteLine($"{item}");
            }
        }


    }
}
