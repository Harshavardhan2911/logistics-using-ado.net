﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LogisticsDA_Lib.Models;
using LogisticsDA_Lib.Repositories;

namespace LogisticsBO_Lib.Models
{
    public class ShipmentBO
    {
       public  static ShipmentRepository shipRep = new ShipmentRepository();

        public static void SearchItem(int shipmentId)

        {

            var item = shipRep.Get(shipmentId);

            if (item == null)

            {

                Console.WriteLine($"{shipmentId} is invalid");

            }

            else

            {

                Console.WriteLine($"{item}");

            }

        }

        public static void UpdateItem(int shipmentId)

        {

            var shipment = shipRep.Get(shipmentId);
            if (shipment == null)
            {
                Console.WriteLine($"{shipmentId} is invalid");
            }
            else
            {
                Console.WriteLine("Re-enter ItemId,Origin,destination,Status and ExpectedDelivery");
                LogisticsDA_Lib.Models.Shipment maint = new LogisticsDA_Lib.Models.Shipment()
                {

                    ShipmentId = shipment.ShipmentId,
                    ItemId = Convert.ToInt32(Console.ReadLine()),
                    Origin = Console.ReadLine(),
                    Destination = Console.ReadLine(),
                    Status= Console.ReadLine(),
                    ExpectedDelivery = Convert.ToDateTime(Console.ReadLine()),

                };
                if (shipRep.DispatchShipment(maint))
                {
                    Console.WriteLine("Shipment Details modified");
                }
                else
                {
                    Console.WriteLine("Schedule Details not modified");
                }
            }


        }

        public static void ReceiveShipment(Shipment shipment)

        {

            LogisticsDA_Lib.Models.Shipment ship = new LogisticsDA_Lib.Models.Shipment()

            {

                ShipmentId=shipment.ShipmentId,

                ItemId = shipment.ItemId,

                Origin = shipment.Origin,

                Destination = shipment.Destination,

                Status = shipment.Status,

                ExpectedDelivery = shipment.ExpectedDelivery



            };

            if (shipRep.ReceiveShipment(ship))

            {

                Console.WriteLine("Shipment Details Added!");

            }

            else

            {

                Console.WriteLine("Shipment Details Could not be added!");

            }

        }

        public static void TrackShipment()

        {

            var shipments = shipRep.GetAll();

            Console.WriteLine("{0,12}{1,12}{2,20}{3,30}{4,20}{5,40}", "ShipmentId", "ItemId", "Origin", "Destination", "Status", "ExpectedDelivery");

            foreach (var shipment in shipments)

            {

                Console.WriteLine($"{shipment}");

            }

        }

    }

}
