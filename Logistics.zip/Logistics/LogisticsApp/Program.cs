﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using LogisticsBO_Lib;
using LogisticsBO_Lib.Models;


namespace LogisticsApp
{
    class Program
    {
        public static void Main( )
        {

            while (true)
            {
                Console.WriteLine("1.Inventory");
                Console.WriteLine("2.Space");
                Console.WriteLine("3.Shipment");
                Console.WriteLine("4.Maintenance");
                Console.WriteLine("5.Report");
                Console.WriteLine("6.Exit");
                int o = Convert.ToInt32(Console.ReadLine());
                switch (o)
                {
                 

                    case 1:
                        while (true)
                        {
                            Console.WriteLine("1. Add Inventory Details");
                            Console.WriteLine("2. View All Inventory Details");
                            Console.WriteLine("3. Search Inventory Details");
                            Console.WriteLine("4. Update Inventory Details");
                            Console.WriteLine("5. Delete Inventory Details");
                            Console.WriteLine("6. Exit");
                            int option = Convert.ToInt32(Console.ReadLine());

                            switch (option)
                            {
                                case 1:
                                    Console.WriteLine("Wish to add Inventory details? Press Y");
                                    string ans = Console.ReadLine();
                                    while (ans.ToUpper()[0] == 'Y')
                                    {
                                        Console.WriteLine("Enter ItemName, Category, Quantity, Location, LastUpdated");
                                        Inventory i = new Inventory()
                                        {
                                            ItemName = Console.ReadLine(),
                                            Category = Console.ReadLine(),
                                            Quantity = int.Parse(Console.ReadLine()),
                                            Location = Console.ReadLine(),
                                            LastUpdated = DateTime.Parse(Console.ReadLine())
                                        };
                                        InventoryBO.AddInventory(i);
                                        Console.WriteLine("Wish to add more Inventory details? Press Y");
                                        ans = Console.ReadLine();
                                    }
                                    break;
                                case 2:
                                    InventoryBO.ViewInventory();
                                    break;
                                case 3:
                                    Console.WriteLine("Enter valid ItemId");
                                    string id1 = Console.ReadLine();
                                    InventoryBO.SearchInventory(id1);
                                    break;
                                case 4:
                                    Console.WriteLine("Enter valid ItemId to Update");
                                    string id = Console.ReadLine();
                                    InventoryBO.UpdateInventory(id);
                                    break;
                                case 5:
                                    Console.WriteLine("Enter valid ItemId to Delete");
                                    string id2 = Console.ReadLine();
                                    InventoryBO.RemoveInventory(id2);
                                    break;
                               case 6:
                                    //  Console.WriteLine("Terminating...");
                                    //  Environment.Exit(0); 
                                   goto outerloop1;

                                    
                                default:
                                    Console.WriteLine("Enter the correct option");
                                    break;
                            }

                        }


                    outerloop1:


                        break;






                    case 2:
                        
                        while (true)
                        {

                            Console.WriteLine("1. Add Space");
                            Console.WriteLine("2. View All Spaces");
                            Console.WriteLine("3. Search Space");
                            Console.WriteLine("4. Delete Space");
                            Console.WriteLine("5. Exit");

                            int op = Convert.ToInt32(Console.ReadLine());

                            switch (op)
                            {
                                case 1:
                                    Console.WriteLine("Wish to add space detailes? Press Y");
                                    string ans = Console.ReadLine();
                                    while (ans.ToUpper()[0] == 'Y')
                                    {
                                        Console.WriteLine("Enter totalCapacity, usedCapacity,  availableCapacity and zone ");
                                        Space s = new Space()
                                        {

                                            TotalCapacity = Convert.ToInt32(Console.ReadLine()),
                                            UsedCapacity = Convert.ToInt32(Console.ReadLine()),
                                            AvailableCapacity = Convert.ToInt32(Console.ReadLine()),
                                            Zone = Console.ReadLine(),
                                        };
                                        SpaceBO.Allocate(s);
                                        Console.WriteLine("Wish to add space detailes? Press Y");
                                        ans = Console.ReadLine();
                                    }
                                    break;

                                case 2:
                                    SpaceBO.Viewspaces();
                                    break;
                                case 3:
                                    Console.WriteLine("Enter valid spaceid");
                                    string id = Console.ReadLine();
                                    SpaceBO.SearchSpace(id);
                                    break;

                                case 4:
                                    Console.WriteLine("Enter valid id for delete");
                                    string id2 = Console.ReadLine();
                                    SpaceBO.RemoveSpace(id2);
                                    break;
                                case 5:
                                    goto outerloop2;
                                default:
                                    Console.WriteLine("Enter the correct option...");
                                    break;

                            }
                        }

                    outerloop2:
                    break;

                    case 3:

                            while (true)

                            {

                                Console.WriteLine("1. RecieveShipment");

                                Console.WriteLine("2. TrackShipment");

                                Console.WriteLine("3. SearchShipment");

                                Console.WriteLine("4. DispatchShipment");

                                Console.WriteLine("5. Exit");

                                int opt = Convert.ToInt32(Console.ReadLine());

                                switch (opt)
                                {

                                    case 1:

                                        Console.WriteLine("Wish to add Shipment details? Press Y");

                                        string ans = Console.ReadLine();

                                        while (ans.ToUpper()[0] == 'Y')

                                        {





                                            Console.WriteLine("Enter ItemId,Origin,Destination,Status,ExpectedDelivery");

                                            Shipment s = new Shipment()

                                            {



                                                ItemId = Convert.ToInt32(Console.ReadLine()),

                                                Origin = Console.ReadLine(),

                                                Destination = Console.ReadLine(),

                                                Status = Console.ReadLine(),

                                                ExpectedDelivery = Convert.ToDateTime(Console.ReadLine())

                                            };

                                            ShipmentBO.ReceiveShipment(s);

                                            Console.WriteLine("Wish to add more Shipment Details? Press Y");

                                            ans = Console.ReadLine();

                                        }

                                        break;

                                    case 2:

                                        ShipmentBO.TrackShipment();

                                        break;

                                    case 3:

                                        Console.WriteLine("Enter Valid ShipmentId");

                                        int id = Convert.ToInt32(Console.ReadLine());

                                        ShipmentBO.SearchItem(id);

                                        break;

                                    case 4:

                                        Console.WriteLine("Enter Valid ShipmentId for Update");

                                        int id2 = Convert.ToInt32(Console.ReadLine());

                                        ShipmentBO.UpdateItem(id2);

                                        break;

                                    case 5:

                                    goto outerloop3;
                                    default:

                                        Console.WriteLine("Enter the correct option...");

                                        break;

                                }



                            }
                    outerloop3:

                        break;

                        case 4:
                            while (true)
                            {
                                Console.WriteLine("1.Add Schedule");
                                Console.WriteLine("2.View Schedule");
                                Console.WriteLine("3.Search Schedule");
                                Console.WriteLine("4.Update Schedule");
                                Console.WriteLine("5.Exit");
                                int opti = Convert.ToInt32(Console.ReadLine());
                                switch (opti) {
                                    case 1:
                                        Console.WriteLine("Wish to add Schedule details?press Y");
                                        string ans = Console.ReadLine();
                                        while (ans.ToUpper()[0] == 'Y')
                                        {
                                            Console.WriteLine("Enter EquipmentId,Description,ScheduledDate and CompletionStatus");
                                            Maintenance m = new Maintenance()
                                            {
                                                //ScheduleId = Convert.ToInt32(Console.ReadLine()),
                                                EquipmentId = Convert.ToInt32(Console.ReadLine()),
                                                Description = Console.ReadLine(),
                                                ScheduledDate = Convert.ToDateTime(Console.ReadLine()),
                                                CompletionStatus = Console.ReadLine()
                                            };
                                            MaintenanceBO.ScheduleMaintenance(m);




                                            Console.WriteLine("Wish to add more Schedule details?press Y");
                                            ans = Console.ReadLine();

                                        }
                                        break;
                                    case 2:
                                        MaintenanceBO.DisplaySchedule();

                                        break;
                                    case 3:
                                        Console.WriteLine("Enter valid Schedule");
                                        string id = Console.ReadLine();
                                        MaintenanceBO.SearchSchedule(id);
                                        break;
                                    case 4:
                                        Console.WriteLine("Enter valid ScheduleId for Update ");
                                        string id2 = Console.ReadLine();
                                        MaintenanceBO.UpdateSchedule(id2);
                                        break;
                                    case 5:
                                    goto outerloop4;
                                    default:
                                        Console.WriteLine("Enter the correct option");
                                        break;


                                }
                            }
                    outerloop4:
                        break;
                        case 5:
                            while (true)
                            {
                                Console.WriteLine("1.GenerateReport");
                                Console.WriteLine("2.DownloadReport");
                                Console.WriteLine("3.Exit");

                                int optio = Convert.ToInt32(Console.ReadLine());
                                switch (optio)
                                {
                                    case 1:
                                        Console.WriteLine("Wish to GenerateReport?press Y");
                                        string ans = Console.ReadLine();
                                        while (ans.ToUpper()[0] == 'Y')
                                        {
                                            Console.WriteLine("Enter ReportType,GeneratedOn and Details");
                                            Report m = new Report()
                                            {
                                                //ScheduleId = Convert.ToInt32(Console.ReadLine()),
                                                ReportType = Console.ReadLine(),

                                                GeneratedOn = Convert.ToDateTime(Console.ReadLine()),
                                                Details = Console.ReadLine()
                                            };
                                            ReportBO.GenerateReport(m);




                                            Console.WriteLine("Wish to generate more?press Y");
                                            ans = Console.ReadLine();

                                        }
                                        break;
                                    case 2:
                                        ReportBO.DownloadReport();

                                        break;


                                    case 3:
                                    goto outerloop5;
                                    default:
                                        Console.WriteLine("Enter the correct option");
                                        break;


                                }
                            }
                    //Console.Read();           

                    outerloop5:


                          break;
                        case 6:
                            Console.WriteLine("Terminating..");
                            Environment.Exit(0);
                            break;

                        default:
                            Console.WriteLine("Enter Correct Option");
                            break;
                        }



          




                }







        }
            
                }

            }
           
           

        
    
        